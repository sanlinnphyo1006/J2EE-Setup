const products = {
  masks: [
    {
      id: 1,
      href: '../collections/masks/pore_clearing_clay_mousse_mask_2x.html',
      imgSrc: '',
      title: {
        main: 'Pore Clearing Clay Mousse Mask 2X',
        sub: 'with Super Volcanic Clusters',
      },
      price: '21',
      quantity: '10',
      category: 'mask',
    },

    {
      id: 2,
      href: '',
      imgSrc:
        'https://cdn.shopify.com/s/files/1/0089/3367/1012/products/1080x1080-MARCH_PACKSHOT_0005_231171119NourishingSleepingMaskwithGingerHoney_1.jpg?v=1615768128&width=1000',
      title: {
        main: 'Nourishing Sleeping Mask',
        sub: 'with Ginger Honey',
      },
      price: '23',
      quantity: '10',
      category: 'mask',
    },

    {
      id: 3,
      href: '',
      imgSrc:
        '//cdn.shopify.com/s/files/1/0089/3367/1012/products/1080x1080-brightening_0002_231171123Brightening_Pore-caringSleepingMask100ml_20.jpg?v=1620683766&width=1440',
      title: {
        main: 'Brightening & Pore-caring Sleeping Mask',
        sub: 'with Jeju Tangerine Peel Extract',
      },
      price: '26',
      quantity: '10',
      category: 'mask',
    },

    {
      id: 4,
      href: '',
      imgSrc: '//cdn.shopify.com/s/files/1/0089/3367/1012/products/NewProject_45.jpg?v=1637629580&width=1440',
      title: {
        main: 'Pore Clearing Calming Clay Mask',
        sub: 'with Volcanic Clusters',
      },
      price: '18',
      quantity: '10',
      category: 'mask',
    },
  ],
};
