/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./*.html', './products/*.html', './assets/js/*.js', './collections/**/*.html', './account/*.html'],
  theme: {
    colors: {
      primary: '#1A2C36',
      secondary: '#3A5660',
      accent: '#95BCCC',
    },
    fontFamily: {
      sans: ['Roboto, sans-serif'],
    },
    extend: {},
  },
  plugins: [],
};
